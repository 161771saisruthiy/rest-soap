package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Test {

	public static void main(String[] args) throws MalformedURLException {

		URL url=new URL("http://localhost:7701/ws/SIMPLEINTREST?wsdl");
        QName qname=new QName("http://capgemini.com/","SimpleIntrestImpService");
		
        Service service=Service.create(url,qname);
        SimpleIntrest si=service.getPort(SimpleIntrest.class);
        System.out.println("simple intrest:"+si.CalculateSI(3000,2.5,4));
	   
		
	}

}
