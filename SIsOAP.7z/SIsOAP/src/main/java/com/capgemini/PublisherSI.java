package com.capgemini;

import javax.xml.ws.Endpoint;

public class PublisherSI {

	public static void main(String[] args) {

		
		Endpoint.publish("http://localhost:7701/ws/SIMPLEINTREST", new SimpleIntrestImp());
	}

}
