package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.SimpleIntrest")

public class SimpleIntrestImp implements SimpleIntrest{

	@Override
	public double CalculateSI(int p, double intrest, int time) {

		
		return (p*intrest*time)/100;
	}

	
	
}
