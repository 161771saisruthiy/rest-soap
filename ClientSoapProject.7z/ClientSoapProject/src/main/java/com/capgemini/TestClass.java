package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;


public class TestClass {

	public static void main(String[] args) throws MalformedURLException {
		URL url=new URL("http://localhost:7703/ws/calculator?wsdl");
        QName qname=new QName("http://capgemini.com/","CalcuImp1Service");
		
        Service service=Service.create(url,qname);
        Calculator cal=service.getPort(Calculator.class);
		//Service.create(url, qname);
        System.out.println("Test Add number:"+cal.addNum(12, 11));
	   
	}

}
